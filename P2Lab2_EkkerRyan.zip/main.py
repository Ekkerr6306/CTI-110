current_price = int(input())
last_months_price = int(input())

price_change = current_price - last_months_price
mortgage = (current_price * 0.051) / 12

print('This house is $' f'{current_price}''.'' The change is $' f'{price_change}'' since last month.')
print('The estimated monthly mortgage is $' f'{mortgage:.2f}''.')
