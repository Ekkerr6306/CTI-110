user_int = int(input('Enter integer (32 - 126):\n'))
user_float = float(input('Enter float:\n'))
user_chr = str(input('Enter character:\n'))
user_str = str(input('Enter string:\n'))

print(user_int, user_float, user_chr, user_str)
print(user_str, user_chr, user_float, user_int)
print(user_int,'converted to a character is', chr(user_int))
#1) Prompt the user to input an integer between 32 and 126, a float, a character, and a string, storing each 
#into separate variables. Then, output those four values on a single line separated by a space.